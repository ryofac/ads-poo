package Revisao.atv_extra.questao02;

import Revisao.atv_extra.questao02.Pessoa;

public class Funcionario extends Pessoa {
    private Double salario;
    private String matricula;
    private Boolean isValid = salario >= 0;

    public Funcionario(String nome, String sobrenome, Double salario, String matricula) {
        super(nome, sobrenome);
        this.salario = salario;
        this.matricula = matricula;

    }

    public Double calcularSalarioPrimeiraParcela() {
        if (!isValid) {
            System.out.println("O salário do funcionário " + get_nome() + " é menor que 0!");
            return -1.0;

        }
        return this.salario * 60 / 100;

    }

    public Double calcularSalarioSegundaParcela() {
        if (!isValid) {
            System.out.println("O salário do funcionário " + get_nome() + " é menor que 0!");
            return -1.0;
        }
        return this.salario * 40 / 100;

    }

    public static void main(String[] args) {
        Double salario = 100.0;
        Funcionario func = new Funcionario("Roberto", "souza", salario, "123321");
        func.calcularSalarioPrimeiraParcela();
    }
}
